
</div>

<script type="text/javascript" src="/stock_system/assets/plugins/fileinput/js/plugins/canvas-to-blob.min.js"></script>
<script type="text/javascript" src="/stock_system/assets/plugins/fileinput/js/plugins/sortable.min.js"></script>
<script type="text/javascript" src="/stock_system/assets/plugins/fileinput/js/plugins/purify.min.js"></script>
<script type="text/javascript" src="/stock_system/assets/plugins/fileinput/js/fileinput.min.js"></script>
<script type="text/javascript" src="/stock_system/assets/plugins/datatables/datattables.min.js"></script>
</body>
</html>